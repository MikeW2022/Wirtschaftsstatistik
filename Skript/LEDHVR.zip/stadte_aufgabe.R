#  St�dte - Aufgabe

#  Im untenstehenden Data Frame sind einige bekannte deutsche St�dte
#  samt Einwohnerzahlen aufgelistet. Die St�dtestruktur nach
#  Einwohnerzahlen soll etwas n�her unter die Lupe genommen werden.

staedte <- read.table("stadte.txt",sep="\t",header=TRUE)

#  a) Lassen Sie sich eine Histogramm �ber die St�dte nach Einwohner-
#     zahlen anzeigen! Klassieren Sie gegebennenfalls die Daten!
#  b) Kann man hier bei einer linkssteilen Verteilung der Einwohner-
#     zahlen ausgehen? Warum?
