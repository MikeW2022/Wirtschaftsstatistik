#  Wohnungsbestand - Aufgabe

#  Bez�glich der Anzahl der Wohnr�ume f�r ein bestimmtes Jahr in der
#  Stadt N ergab die Statistik des Wohnungsbestands folgendes Bild:

wohnungsbestand <- data.frame(Raumanzahl=1:7,Wohnungsanzahl=c(130,615,1855,2720,1147,383,120))

#  a) Pr�sentieren Sie die Verteilungsstruktur der Wohnr�ume in der
#     Stadt N mit Hilfe einer geeigneten Graphik.
#  b) Stellen Sie die empirische Verteilungsfunktion analytisch und
#     graphisch dar. 
#  c) Geben Sie den Wert der empirischen Verteilungsfunktion an der
#     Stelle 4 an und interpretieren Sie ihn.
#  d) Wieviel Prozent der Wohnungen besitzen weniger als vier Wohnr�ume?
#  e) Geben Sie den Anteil der Wohnungen an, die mehr als zwei, aber
#     weniger als f�nf Wohnr�ume besitzen.

##########

#  Wohnungsbestand - L�sung

#  a)
#  F�r die Verteilungsstruktur wird ein S�ulendiagramm gezeichnet
barplot(wohnungsbestand$Wohnungsanzahl,names.arg=c("1","2","3","4","5","6",">= 7"),main="Saeulendiagramm",xlab="Zimmeranzahl",ylab="Haeufigkeiten")

#  b)
abs.hkeit <- wohnungsbestand$Wohnungsanzahl
rel.hkeit <- abs.hkeit/sum(wohnungsbestand$Wohnungsanzahl)
fn <- cumsum(rel.hkeit)
plot(wohnungsbestand$Raumanzahl,fn,type="n",xlab="Raumanzahl",ylab="Fn",main="Verteilungsfunktion")
lines(wohnungsbestand$Raumanzahl,fn,type="s")

#  c)
fn[4]
#  Das bedeutet, dass 76,33 % der Wohnungen 4 oder weniger R�ume haben.

#  d)
fn[3]
#  Denn das bedeutet, dass 37,30 % h�chstens drei, also weniger
#  als vier Zimmer haben.

#  e)
fn[4]-fn[2]