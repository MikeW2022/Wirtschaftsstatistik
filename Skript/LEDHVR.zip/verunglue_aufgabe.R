# Verungl�ckte im Stra�enverkehr - Aufgabe

#  Im unten stehenden Data Frame sind die im Stra�enverkehr von
#  1975- 1998 verungl�ckten Personen (alte Bundesl�nder) quantitativ
#  erfasst. Diese Daten sollen Sie n�her betrachten!

verunglueckte <- data.frame(Jahr=1975:1998,Verunglueckte=c(472667,495401,523120,523306,499663,513504,487618,478796,500942,476232,430495,452165,432589,456436,457392,456064,429482,433081,418240,422069,415065,397202,405279,405830))

#  a) Lassen Sie sich ein S�ulendiagramm zu den Verungl�ckten
#     erstellen! Warum ist dies aber nicht die geeignete
#     Darstellungsform f�r diesen Datensatz?
#  b) Erstellen Sie nun ein Histogramm mit 9 Klassen und konstanter
#     Klassenbreite. In welche Klasse fallen die meisten
#     Erfassungsjahre?
#  c) Angenommen, die Klassenbreite w�re nicht konstant.
#     Was m�ssten Sie beachten, falls Sie die H�ufigkeiten
#     einzelner Klassen analysieren wollten?
