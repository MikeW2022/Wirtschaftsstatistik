#  Prosecco - Aufgabe

#  Der Inhaber des Weinfachgesch�ftes Maestro hat eine neue
#  Proseccosorte in sein Sortiment aufgenommen und interessiert
#  sich f�r die Anzahl der pro Tag verkauften Flaschen dieser Sorte.
#  Vier Wochen lang hat er t�glich die Anzahl der verkauften
#  Flaschen notiert und im folgenden Data-Frame zusammengefasst.

prosecco <- data.frame(Flaschenanzahl=c(0,2,3,5,7,8),Tage=c(3,5,7,4,3,2))

#  a) Bestimmen Sie zu den absoluten H�ufigkeiten die relativen
#     H�ufigkeiten und berechnen Sie jeweils die kumulierten
#     H�ufigkeiten.

#  b) Stellen Sie die empirische Verteilungsfunktion sowohl analytisch
#     als auch graphisch dar.

#  c) Bestimmen und interpretieren Sie den Wert der empirischen
#     Verteilungsfunktion an der Stelle 5.

##########

#  Prosecco - L�sung

#  a)
abs.hkeit <- prosecco$Tage
rel.hkeit <- abs.hkeit/sum(abs.hkeit)

#Ausgabe der absoluten H�ufigkeitsverteilung
abs.hkeit

#Ausgabe der relativen H�ufigkeitsverteilung
rel.hkeit

kum.abs.hkeit <- cumsum(abs.hkeit)
kum.rel.hkeit <- cumsum(rel.hkeit)

#Ausgabe der kumulierten absoluten H�ufigkeitsverteilung
kum.abs.hkeit

#Ausgabe der kumulierten relativen H�ufigkeitsverteilung
kum.rel.hkeit


#  b)
fn <- kum.rel.hkeit
plot(prosecco$Flaschenanzahl,fn,type="n",xlab="Flaschenanzahl",ylab="Fn",main="Verteilungsfunktion")
lines(prosecco$Flaschenanzahl,fn,type="s")

#  c)
fn[5]

#  An 91,67 % der Tage werden 7 oder weniger Flaschen der neuen
#  Proseccosorte verkauft.
#  Das hei�t: An 8,33 % der Tage werden acht (oder mehr) Flaschen
#  der neuen Proseccosorte verkauft.