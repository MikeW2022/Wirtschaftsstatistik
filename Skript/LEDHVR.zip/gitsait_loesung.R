#  Gitarrensaiten - Aufgabe

#  Ein Gitarist schrieb auf, wieviele Stunden Spieldauer eine jede
#  (insgesamt 23) E1-Saite (die d�nnste Seite einer normalen Gitarre)
#  h�lt, bevor sie rei�t.

spieldauer <- c(12,24,3,14,5,21,38,30,23,14,24,11,9,10,7,13,17,19,16,26,24,27,29)

#  a) Bestimmen Sie die absolute und die relative H�ufigkeitsverteilung
#     und zeichnen Sie ein S�ulendiagramm. Beurteilen Sie jeweils
#     die Aussagekraft!
#  b) Teilen Sie die Daten in Klassen (Breite 10) ein und zeichnen
#     Sie ein Histogramm der klassierten Daten. Beurteilen Sie auch
#     hier die Aussagekraft.

##########

#  Gitarrensaiten - L�sung

#  a)
#  H�ufigkeitstabelle

abs.hkeit <- table(spieldauer)
rel.hkeit <- table(spieldauer)/length(spieldauer)

#Ausgabe der absoluten H�ufigkeitsverteilung
abs.hkeit

#Ausgabe der relativen H�ufigkeitsverteilung
rel.hkeit

#  S�ulendiagramm

# Einfache S�ulendiagramme (s. R barplot) ber�cksichtigen nicht die tas�chlichen
# Werte der Kategorien. Deshalb m�ssen wir etwas gr�ndlicher vorgehen.
# zun�chst werden die vorkommenden Spieldauern ermittelt:
#	 as.numeric(names(abs.hkeit))
# danach die absoluten H�ufigkeiten als senkrechte Linien eingezeichnet
#	type="h" ein wenig dicker lwd=3
# die Koordinatenachsen und sch�ne Beschriftung sind dann auch fix eingef�gt.
 
plot(as.numeric(names(abs.hkeit)),abs.hkeit,
xlab="Spieldauer",ylab="absolute H�ufigkeit",
type="h",lwd=3,xlim=c(0,40),ylim=c(0,3.5),axes=F)
axis(1,at=5*(0:8))
axis(2,at=0:3)
box()
#  Das gezeichnete S�ulendiagramm hat begrenzte Aussagekraft, weil die Spieldauer der einzelnen Gitarrensaiten zu fein skaliert ist. Deshalb kommen die meisten Stundenzahlen nur einmal vor.

#  b)

#  Histogramm mit Klassenbreite 10

hist(spieldauer,breaks=c(0,10,20,30,40),main="Histogramm",xlab="Spieldauer",freq=F,col="grey")


#  In dem gezeichneten Histogramm ist die H�ufigkeitsverteilung
#  schon besser zu erkennen. Die meisten Gitarrensaiten rei�en
#  nach etwa 10 bis 30 Stunden Spieldauer. F�r genauere Folgerungen
#  kann weiter mit der Klasseneinteilung "gespielt" werden.