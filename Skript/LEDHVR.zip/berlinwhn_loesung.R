#  Berliner Wohnungen - Aufgabe

#  Der Data Frame gibt die am 26. September 2001 in Berlin zur Miete
#  angebotenen Wohnungen wieder. Es werden die Zahl der Zimmer genannt und die Nettokaltmiete in Euro. Verschaffen Sie sich einen �berblick �ber den Wohnungsmark bzgl. der Zimmerzahl und bzgl. der Preise! Nutzen Sie auch die grafischen M�glichkeiten.

mietwohnungen <- read.table("berlinwhn.txt",sep="\t",header=TRUE)

#  Beantworten Sie zum Schlu� folgende Fragen:
#  1) Wie gro� ist meine Chance f�r meine Gro�familie eine
#     7-Zimmerwohnung zu bekommen?
#  2) Wohnungen mit wieviel Zimmer waren in Berlin zu diesem
#     Zeitpunkt am leichtesten zu finden?
#  3) In welchem Preissegment gibt es die meisten Wohnungen?

##########

#  Berliner Wohnungen - L�sung



attach(mietwohnungen)

#  H�ufigkeitsverteilungen von Zimmeranzahl und Preis

table(Zimmer)
table(Preis)

#  Zur Veranschaulichung:
#  S�ulendiagramm f�r Zimmer, Histogramm f�r Preis (klassifiziert)


opar<-par(mfrow=c(1,2))
barplot(table(Zimmer),main="Verteilung der Zimmer",xlab="Anzahl der Zimmer",ylab="Anzahl der Wohnungen")
hist(Preis,main="Histogramm f�r den Preis",freq=F,xlab="Preis",col="grey")

par(opar)

#  1) Die Chance eine 7-Zimmerwohnung zu bekommen:


table(Zimmer)[7]/length(Zimmer)


#  2) Das S�ulendiagramm zeigt:
#     2-Zimmerwohnungen waren zu diesem Zeitpunkt am leichtesten
#     zu finden


#  3) Das Histogramm zeigt:
#     Wohnungen im Preissegment von  bis 500 Euro waren am
#     leichtesten zu finden