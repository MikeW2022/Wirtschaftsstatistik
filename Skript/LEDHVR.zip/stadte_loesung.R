#  St�dte - Aufgabe

#  Im untenstehenden Data Frame sind einige bekannte deutsche St�dte
#  samt Einwohnerzahlen aufgelistet. Die St�dtestruktur nach
#  Einwohnerzahlen soll etwas n�her unter die Lupe genommen werden.

staedte <- read.table("stadte.txt",sep="\t",header=TRUE)

#  a) Lassen Sie sich eine Histogramm �ber die St�dte nach Einwohner-
#     zahlen anzeigen! Klassieren Sie gegebennenfalls die Daten!
#  b) Kann man hier bei einer linkssteilen Verteilung der Einwohner-
#     zahlen ausgehen? Warum?

##########

#  St�dte - L�sung

#  a)

#  Standardhistogramm von R (Histogramm a)

hist(staedte$Einwohner,freq=F,main="Histogramm",xlab="Einwohnerzahl",col="grey")
#  Genauere Darstellung, nicht unbedingt besser (Histogramm b)
hist(staedte$Einwohner,freq=F,breaks=seq(100000,3400000,100000),main="Histogramm b",xlab="Einwohnerzahl",col="grey")

#  b)
#  Man kann durchaus von einer linkssteilen Verteilung der Daten
#  sprechen, da der Gro�teil der St�dte am "linken Ende" der Skala
#  liegt.