#  Berliner Wohnungen - Aufgabe

#  Der Data Frame gibt die am 26. September 2001 in Berlin zur Miete
#  angebotenen Wohnungen wieder. Es werden die Zahl der Zimmer genannt und die Nettokaltmiete in Euro. Verschaffen Sie sich einen �berblick �ber den Wohnungsmark bzgl. der Zimmerzahl und bzgl. der Preise! Nutzen Sie auch die grafischen M�glichkeiten.

mietwohnungen <- read.table("berlinwhn.txt",sep="\t",header=TRUE)

#  Beantworten Sie zum Schlu� folgende Fragen:
#  1) Wie gro� ist meine Chance f�r meine Gro�familie eine
#     7-Zimmerwohnung zu bekommen?
#  2) Wohnungen mit wieviel Zimmer waren in Berlin zu diesem
#     Zeitpunkt am leichtesten zu finden?
#  3) In welchem Preissegment gibt es die meisten Wohnungen?
