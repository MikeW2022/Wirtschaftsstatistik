#  Arbeitsunf�lle - Aufgabe

#  Im April diesen Jahres wurde die Anzahl der Arbeitsunf�lle in
#  Firma Vladimir&Co, durch die jeweils ein Firmenbesch�ftigter in
#  Mitleidenschaft gezogen wurde, statistisch erfasst und aufbereitet.
#  Es ergab sich, dass 90 % der Besch�ftigten keinen Arbeitsunfall
#  hatten, 7% hatten einen Arbeitsunfall und 3% hatten genau zwei
#  Arbeitsunf�lle. 

#  Berechnen Sie die Werte der empirische Verteilungsfunktion und
#  Zeichnen Sie diese.
