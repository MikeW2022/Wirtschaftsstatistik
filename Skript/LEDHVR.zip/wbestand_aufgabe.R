#  Wohnungsbestand - Aufgabe

#  Bez�glich der Anzahl der Wohnr�ume f�r ein bestimmtes Jahr in der
#  Stadt N ergab die Statistik des Wohnungsbestands folgendes Bild:

wohnungsbestand <- data.frame(Raumanzahl=1:7,Wohnungsanzahl=c(130,615,1855,2720,1147,383,120))

#  a) Pr�sentieren Sie die Verteilungsstruktur der Wohnr�ume in der
#     Stadt N mit Hilfe einer geeigneten Graphik.
#  b) Stellen Sie die empirische Verteilungsfunktion analytisch und
#     graphisch dar. 
#  c) Geben Sie den Wert der empirischen Verteilungsfunktion an der
#     Stelle 4 an und interpretieren Sie ihn.
#  d) Wieviel Prozent der Wohnungen besitzen weniger als vier Wohnr�ume?
#  e) Geben Sie den Anteil der Wohnungen an, die mehr als zwei, aber
#     weniger als f�nf Wohnr�ume besitzen.
