#  Wohnungen - Aufgabe

#  Bei dem Blick in den Wohnungsteil der lokalen Tageszeitung ist
#  es schwierig bis unm�glich einen �berblick �ber den Wohnungsmarkt zu
#  bekommen. Im Vektor "zimmerzahl" wird die Zimmeranzahl der freien 
#  Wohnungen in Berlin am 26. Juni 2022 gespeichert. Bestimmen Sie die
#  absoluten H�ufigkeiten, verdeutlichen Sie die Verteilung der absoluten
#  H�ufigkeiten in einem S�ulendiagramm und lassen Sie die
#  Verteilungsfunktion zeichnen. Interpretieren Sie beide Darstellungs-
#  formen.

zimmerzahl <- c(1,2,2,2,2,2,3,3,4,3,1,1,1,3,5,2,5,4,5,1,1,1,3,1,2,4,4,3,1,2,1,2,1,3,3,2,2,4,6,4,6,4,2,5,5,4,3,2,2,2,2,3,2,3,2,3,2,4,3,3,3,2,2,3,2,2,2,3,4,4,2,2,2,3,2,2,3,4,3,3,3,3,2,2)
