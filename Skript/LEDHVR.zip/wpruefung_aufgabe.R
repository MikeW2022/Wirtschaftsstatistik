#  Wiederholungspr�fung - Aufgabe

#  Der Vektor �wiederholung� beinhaltet die Anzahl der Wiederholungspr�fungen von 117 Studenten 
#  und Studentinnen im Fach Statistik einer Berliner Fachhochschule, die im Verlauf des WS 2021 ihre Pr�fung absolvierten.

wiederholung <- c(0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,2,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,3,0,0,1,0,0,0,0,2,0,1,0,1,0,1,0,0,0,1,0,0,1,1,0,1,0,0,1,0,0,0,0,0,1,0,0,0,1,0,2,1,1,0,0,0,0,0,1,0,1,1,1,1,0,2,0,1,1,2,1,1,0,1,0)

#  a) Bestimmen Sie die relativen und absoluten
#     H�ufigkeiten.
#  b) Stellen Sie die H�ufigkeitsverteilung des Erhebungsmerkmals
#     graphisch dar. 
#  c) Geben Sie die Formel der empirische Verteilungsfunktion des Erhebungs-
#     merkmals an und stellen Sie diese grafisch dar. 
#  d) Wie viel Prozent der Studenten bestanden nicht im ersten
#     Anlauf die Statistikpr�fung.