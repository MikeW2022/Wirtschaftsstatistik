#  Mathenoten - Aufgabe

#  Ein Lehrer m�chte die Noten von seinen 20 Sch�lern in Mathematik
#  untersuchen.

#  Noten:
#  1.3, 2.7, 4.7, 1.0, 2.3, 5.0, 3.3, 1.7, 1.0, 1.3,
#  2.0, 2.7, 2.3, 3.7, 3.3, 2.3, 2.3, 1.7, 2.7, 2.0

#  a) Bestimmen Sie die H�ufigkeitsverteilung und stellen Sie die Daten
#     in einem S�ulendiagramm und in einem Histogramm
#     (Klassenbreite=1) dar.

#  b) Erstellen Sie von den Daten 5 Klassen, wobei die Klassen
#     wie folgt eingeteilt sind. 
#  	1 : 1.0-1.3
#	2 : 1.7-2.3
#	3 : 2.7-3.3
#	4 : 3.7-4.3
#	5 : 4.7-5.0
#  Erzeugen Sie von den Klassen ein Histogramm.

#  c) Vergleichen Sie das Histogramm von a und b. 

##########

#  Mathenoten - L�sung

#  a)
noten <- c(1.3, 2.7, 4.7, 1.0, 2.3, 5.0, 3.3, 1.7, 1.0, 1.3, 2.0, 2.7, 2.3, 3.7, 3.3, 2.3, 2.3, 1.7, 2.7, 2.0)
abs.hkeit <- table(noten)

#Ausgabe der absoluten H�ufigkeitsverteilung
abs.hkeit

# Einfache S�ulendiagramme (s. R barplot) ber�cksichtigen nicht die tas�chlichen
# Werte der Kategorien. Deshalb m�ssen wir etwas gr�ndlicher vorgehen.
# Wir erweitern die beobachteten H�ufigkeiten einfach um die Werte 0 f�r
# Noten, die in unserem Datensatz nicht auftreten. 
# Dann liefert uns die R funktion barplot eine korrekte Darstellung.

hk<-rep(0,13)
names(hk)<- c(1,1.3,1.7,2,2.3,2.7,3,3.3,3.7,4,4.3,4.7,5)
hk[names(abs.hkeit)]<-abs.hkeit
barplot(hk,main="Saeulendiagramm",xlab="Noten",ylab="Haeufigkeiten",
        ylim=c(0,4.5))
box()

hist(noten,breaks=c(0,1,2,3,4,5),main="Histogramm a",xlab="Noten",freq=F,col="grey")

#  b)
noten.klass<-cut(noten,breaks=c(0.3,1.3,2.3,3.3,4.3,5.3))
table(noten.klass)
hist(noten, breaks=c(0.3,1.3,2.3,3.3,4.3,5.3),freq=F,main="Histogramm b",xlab="Klassen",col="grey")

#  c)
#  Vergleich:
#  Es wird sichtbar, dass bei unterschiedlicher Wahl der Klassen
#  auch unterschiedliche Verteilungen zu erkennen sind. Hierbei muss
#  abgew�gt werden, welche Klassenwahl besser geeignet ist.
#  Da bei der Noteneinteilung in die Notenbl�cke "sehr gut", "gut",
#  usw. wie bei der Klassenwahl im Aufgabenteil b eingeteilt wird,
#  ist das Histogramm b f�r diese Aufgabe wohle besser geeignet.