#  Radtraining - Aufgabe

#  Ein Radfahrer f�hrt eine Trainingsliste, in die unter anderem
#  die gefahrenen Kilometer pro Trainingsfahrt eintragen werden.
#  Aus dieser Liste stammen die unten angegebenen Daten. Betrachtet
#  auf die 20.000 - 25.000 km Jahresgesamtstrecke eines aktiven
#  Radprofis ist dies nur ein kleiner Teil, der hier aber mal n�her
#  betrachtet werden soll.

trainingsliste <- c(70,125,85,80,85,70,75,80,75,70,80,120,80,55,85,85,90,80,80,125,85)

#  a) Bestimmen Sie die absolute und die relative H�ufigkeitsverteilung.
#     Bestimmen Sie au�erdem die Werte der empirischen Verteilungs-
#     funktion und zeichnen Sie diese.
#  b) 80 % der hier aufgef�hrten Trainingsfahrten sind nicht l�nger als?
