#  Gitarrensaiten - Aufgabe

#  Ein Gitarist schrieb auf, wieviele Stunden Spieldauer eine jede
#  (insgesamt 23) E1-Saite (die d�nnste Seite einer normalen Gitarre)
#  h�lt, bevor sie rei�t.

spieldauer <- c(12,24,3,14,5,21,38,30,23,14,24,11,9,10,7,13,17,19,16,26,24,27,29)

#  a) Bestimmen Sie die absolute und die relative H�ufigkeitsverteilung
#     und zeichnen Sie ein S�ulendiagramm. Beurteilen Sie jeweils
#     die Aussagekraft!
#  b) Teilen Sie die Daten in Klassen (Breite 10) ein und zeichnen
#     Sie ein Histogramm der klassierten Daten. Beurteilen Sie auch
#     hier die Aussagekraft.
