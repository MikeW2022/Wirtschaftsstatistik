#  Mathenoten - Aufgabe

#  Ein Lehrer m�chte die Noten von seinen 20 Sch�lern in Mathematik
#  untersuchen.

#  Noten:
#  1.3, 2.7, 4.7, 1.0, 2.3, 5.0, 3.3, 1.7, 1.0, 1.3,
#  2.0, 2.7, 2.3, 3.7, 3.3, 2.3, 2.3, 1.7, 2.7, 2.0

#  a) Bestimmen Sie die H�ufigkeitsverteilung und stellen Sie die Daten
#     in einem S�ulendiagramm und in einem Histogramm
#     (Klassenmbreite=1) dar.

#  b) Erstellen Sie von den Daten 5 Klassen, wobei die Klassen
#     wie folgt eingeteilt sind. 
#  	1 : 1.0-1.3
#	2 : 1.7-2.3
#	3 : 2.7-3.3
#	4 : 3.7-4.3
#	5 : 4.7-5.0
#  Erzeugen Sie von den Klassen ein Histogramm.

#  c) Vergleichen Sie das Histogramm von a und b. 
