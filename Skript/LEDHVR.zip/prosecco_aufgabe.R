#  Prosecco - Aufgabe

#  Der Inhaber des Weinfachgesch�ftes Maestro hat eine neue
#  Proseccosorte in sein Sortiment aufgenommen und interessiert
#  sich f�r die Anzahl der pro Tag verkauften Flaschen dieser Sorte.
#  Vier Wochen lang hat er t�glich die Anzahl der verkauften
#  Flaschen notiert und im folgenden Data-Frame zusammengefasst.

prosecco <- data.frame(Flaschenanzahl=c(0,2,3,5,7,8),Tage=c(3,5,7,4,3,2))

#  a) Bestimmen Sie zu den absoluten H�ufigkeiten die relativen
#     H�ufigkeiten und berechnen Sie jeweils die kumulierten
#     H�ufigkeiten.

#  b) Stellen Sie die empirische Verteilungsfunktion sowohl analytisch
#     als auch graphisch dar.

#  c) Bestimmen und interpretieren Sie den Wert der empirischen
#     Verteilungsfunktion an der Stelle 5.
