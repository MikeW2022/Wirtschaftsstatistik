#  Studentische Gr��en - Aufgabe

#  Eine von Statistikstudenten durchgef�hrte Befragung im WS 2021,
#  ergab folgende Werte der K�rpergr��en von Studenten:

groesse<-c(194,179,169,175,181,188,187,171,176,169,168,176,175,168,169,174,186,169,177,183,177,170,172,172,174,163,181,187,189,167,189,176,165,173,176,181,182,165,174,184,168,158,192,176,167,169,160,182,168,174)

#  a) Berechnen Sie die absoluten und die relativen H�ufigkeiten.
#     Berechnen Sie au�erdem die Werte der empirischen Verteilungs-
#     funktion und stellen Sie diese graphisch dar.
#  b) Wie hoch ist der Anteil der Studenten, die
#	- kleiner als 150 sind ?
#	- gr��er als 180 sind?
#	- mindestens 175 sind?
#	- h�chstens 175 sind?
#  c) Welche Gr��e wird von
#	- 25% der Studenten nicht �berschritten?
#	- 50% der Studenten �bertroffen?
#	- 80% der Studenten nicht erreicht?
