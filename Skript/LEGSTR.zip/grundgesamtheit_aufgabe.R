#  Grundgesamtheit - Aufgabe

#  Nennen Sie zu folgenden Fragestellungen die jeweils relevante
#  Grundgesamtheit:
#  1) Wird die FDP die 5% H�rde �berspringen k�nnen?
#  2) Wie hoch ist der Frauenanteil in ihrem Kurs
#     Wirtschaftsmathematik 1?
#  3) Wie gro� ist das durschnittliche K�rpergewicht
#     vollj�hriger Bundesb�rger?
#  4) Wie wirken sich die Luftschadstoffe auf die Gesundheit
#     der Lungen von Neugeborenen in der EU aus?
#  5) Wie lange ist die durschnittliche Lebensdauer einer 40 Watt
#     Gl�hbirne?

#  Zusatz:
#  In welchen F�llen ist eine Totalerhebung sinnvoll, wann eine
#  Stichprobe? Worauf ist bei der Benutzung einer Stichprobe zur
#  Beantwortung der Fragen zu achten?
