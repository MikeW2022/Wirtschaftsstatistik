#  Kursliste - Aufgabe

#  Erfragen Sie per e-mail oder Telefon folgende Informationen �ber
#  Ihre KomilitonInnen: Vorname, Nachname, Alter, Gr��e, Gewicht.
#  1. Erstellen Sie einen Data Frame mit Ihren Ergebnissen.
#  2. Welche Merkmale sind nominal-, welche verh�ltnis-,
#     intervall- oder absolutskaliert ?
