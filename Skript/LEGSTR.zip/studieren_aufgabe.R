#  Studieren ist sch�n - Aufgabe

#  Im Wintersemester 2000/01 wurde die Studienbedingungen von
#  Studenten in Berlin untersucht. Dazu wurden 50 Studenten nach
#  folgenden Merkmalen untersucht.

#  Merkmal A: "Geschlecht"
#  Merkmal B: "Studienfach (Hauptfach)"
#  Merkmal C: "Anzahl der Semester"
#  Merkaml D: "Zufriedenheit mit dem Studium"
#  Merkmal E: "Art der Hochschule"
#  Merkmal F: "Monatliches Einkommen"
#  Merkmal G: "Intelligenzquotient"

#  a) Nennen Sie f�r jedes Merkmal zwei m�gliche Auspr�gungen
#     und geben sie an, ob es sich um ein qualitatives oder
#     quantitatives Merkmal handelt. Geben Sie f�r quantitative
#     Merkmale an, ob diese mit einer Intervall-, Verh�ltnis-
#     oder Absolutskala gemessen werden.

#  b) F�r das Merkmal D: "Zufriedenheit mit dem Studium" wurden
#     in der Befragung folgende (Urbild-) Klassen vorgegeben:

#  	D1: "zufrieden"
#	D2: "normal"
#	D3: "unzufrieden" 

#  und folgenderma�en gemessen:

#	d1=1 
#	d2=2 
#	d3=3 

#  Begr�nden Sie, welche der zwei fogenden Merkmalstransformationen
#  zul�ssig sind:

#  (i)	x1=1 
#	x2=10 
#	x3=100

#  (ii)	y1=1 
#	y2=10 
#	y3=5
