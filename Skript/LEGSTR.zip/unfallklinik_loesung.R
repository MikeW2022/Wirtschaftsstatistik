#  Unfallklinik - Aufgabe

#  Gegeben sei folgender Datensatz

patienten <- data.frame(Alter=c(35,23,40,29,24,18,28,20),Geschlecht=c("m","m","w","m","w","w","w","w"),Verletzungsgrad=c("leicht","leicht","mittel","schwer","mittel","schwer","leicht","mittel"),Verweildauer=c(20,11,28,23,7,15,18,8),Verkehrsmittel=c("Fahrrad","zu Fuss","zu Fuss","Motorrad","Auto","Auto","Auto","Fahrrad"))

#  a) Benennen Sie die Skalierung der 5 statistischen Variablen.
#  b) Nennen Sie weitere Beispiele von Variablen f�r diese Skalenarten.
#  c) Stellen Sie die H�ufigkeitsverteilung der an den Unf�llen
#     beteiligten Verkehrsmittel als S�ulendiagramm dar.

##########

#  Unfallklinik - L�sung

#  a)
#  Alter - verh�ltnis
#  Geschlecht - nominal
#  Verletzungsgrad - ordinal
#  Verweildauer - metrisch (ratio)
#  Verkehrsmitel - nominal

#  b)
#  nominal: Name, Familienstand, Haarfarbe, Augenfarbe, Beruf
#  ordinal: Zensuren, Lohngruppen, Olympiamedaillen, G�teklasse        
#  metrisch (intervall): Temperatur (in C)
#  metrisch (ratio): Bruttoverdienst, bezahlte Stunden,
#                    Temperatur (in K), L�nge, Zeit

#  c)
barplot(table(patienten$Verkehrsmittel),main="Haeufigkeitsverteilung",ylab="abs. Haeufigkeit")