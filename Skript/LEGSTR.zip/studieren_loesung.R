#  Studieren ist sch�n - Aufgabe

#  Im Wintersemester 2000/01 wurde die Studienbedingungen von
#  Studenten in Berlin untersucht. Dazu wurden 50 Studenten nach
#  folgenden Merkmalen untersucht.

#  Merkmal A: "Geschlecht"
#  Merkmal B: "Studienfach (Hauptfach)"
#  Merkmal C: "Anzahl der Semester"
#  Merkaml D: "Zufriedenheit mit dem Studium"
#  Merkmal E: "Art der Hochschule"
#  Merkmal F: "Monatliches Einkommen"
#  Merkmal G: "Intelligenzquotient"

#  a) Nennen Sie f�r jedes Merkmal zwei m�gliche Auspr�gungen
#     und geben sie an, ob es sich um ein qualitatives oder
#     quantitatives Merkmal handelt. Geben Sie f�r quantitative
#     Merkmale an, ob diese mit einer Intervall-, Verh�ltnis-
#     oder Absolutskala gemessen werden.

#  b) F�r das Merkmal D: "Zufriedenheit mit dem Studium" wurden
#     in der Befragung folgende (Urbild-) Klassen vorgegeben:

#  	D1: "zufrieden"
#	D2: "normal"
#	D3: "unzufrieden" 

#  und folgenderma�en gemessen:

#	d1=1 
#	d2=2 
#	d3=3 

#  Begr�nden Sie, welche der zwei fogenden Merkmalstransformationen
#  zul�ssig sind:

#  (i)	x1=1 
#	x2=10 
#	x3=100

#  (ii)	y1=1 
#	y2=10 
#	y3=5

##########

#  Studieren ist sch�n - L�sung

#  a)
#  Beispiele:

#  A: 1 ("weiblich"), 2 ("m�nnlich")
#  B: 1 ("Mathematik"), 2 ("Medizin"), ...
#  C: 1 ("1 Semester"), 2 ("2 Semester"), ... 
#  D: 1 ("sehr zufrieden"), 2 ("zufrieden"), ...
#  E: 1 ("Universit�t"), 2 ("Fachhochschule"), ...
#  F: 250 ("250 DM"), 800 ("800 DM"), ...
#  G: 90 ("IQ 90"), 110 ("IQ 110"), ...

#  Bei Merkmal A, B und E sind weder Reihenfolge noch Abst�nde der
#  Auspr�gungen sinnvoll interpretierbar. Es handelt sich deshalb
#  um qualitative Merkmale, die eine Nominalskala darstellen.

#  Die Auspr�gungen des Merkmals D lassen sich zwar der Reihen nach
#  ordnen, die Abst�nde k�nnen aber nicht (objektiv) gemessen werden.
#  Es handelt sich um ein qualitatives Merkmal, das eine
#  Ordinalskala ist.

#  Das Merkmal C, F und G sind quantitativ und werden mit einer
#  Kardinalskala gemessen, denn sowohl die Reihenfolge als auch die
#  Abst�nde zwischen den Werten besitzen inhaltliche Bedeutung.

#  Da die Skala beim Merkmal F einen nat�rlichen Nullpunkt, aber
#  keine nat�rliche Einheit besitzt (so ist die W�hrungseinheit
#  willk�rlich gew�hlt), handelt es sich um eine Verh�ltnisskala.

#  Da diese Skala beim Merkmal C neben dem nat�rlichen Nullpunkt
#  auch eine nat�rliche Einheit aufweist, handelt es sich um eine
#  Absolutskala.

#  Beim Merkmal G handelt es sich um eine Intervallskala, denn es
#  ist kein nat�rlicher Nullpunkt und keine nat�rliche Einheit voranden.

#  b)
#  Die Tranfsormation (i) ist zulassig, da es sich bei x um eine
#  monotone Transformation von d handelt:
#  di <=dj   --> x(di)=xi <= x(dj)=xj
#  (Die Abst�nde zwischen dem Merkmalsauspr�gungen k�nnen unterschiedlich gro� sein, da sie nicht sinnvoll interpretiert werden)

#  Die Transformation (ii) ist dagegen nicht zul�ssig:
#  Es gilt		d1 <d2   und y(d1)=y1 < y(d2)=y2
#  gleichzeitig aber 	d2 <d3   und y(d2)=y2 > y(d3)=y3
#  Bei y(d) handelt es sich nicht um eine monotone Transformation.