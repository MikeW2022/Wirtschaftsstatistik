#  Auto - Aufgabe

#  Ford Mustang (ERST 20 TKM)
#  EUR 6.596
#  D-10439, EZ: 07/98, 20.000 km, 77 kW, blau, 
#  VOLLAUSSTATTUNG: Automatikgetriebe, ...

#  Ford Probe 16V Medici Leder
#  EUR 6.642
#  D-14542, EZ: 04/98, 31.000 km, 85 kW, silber, 
#  T�V 04/03, Leder, 2xAirbag, ABS, Servo, ZV, ...

#  Opel Astra F-cc 1.6 16VSport
#  EUR 6.851
#  D-13583, EZ: 04/96, 49.542 km, 74 kW, gr�n, 
#  T�V 04/03, ZV + Alarm, 2xAirbag, ...

#  Die oben stehenden Angebote sind Ergebnisse aus
#  einer Suche nach Gebrauchtwagen im Internet. 

#  1. Was ist in dieser Aufgabe eine statistische Einheit? 
#  2. Welche Merkmale kommen in den Daten vor? 
#  3. Geben Sie f�r jedes Merkmal die Skala an, auf der es gemessen wurde.


##########

#  Auto - L�sung

#  1. Ein Auto 
#  2. Name, Preis, Standort, Monat der Erstzulassung, km-Stand, Leistung, Farbe, Ausstattung 
#     Das Besondere am Merkmal �Ausstattung� ist, dass es mehrere Auspr�gungen gleichzeitig annehmen kann. 
#     Ein solches Merkmal wird �h�ufbar� genannt, was aber in diesem Kurs nicht weiter behandelt wird. 
#     Das Besondere am Merkmal �n�chster T�V-Termin� ist, dass es bei einer statistischen Einheit einen fehlenden Wert gibt. 
#  3. Name: nominal skaliert - wie der Name schon sagt :-) 
#  Preis: Verh�ltnisskala 
#  Standort: Nominalskala 
#  Monat der Erstzulassung: Intervallskala 
#  km-Stand: Absolutskala 
#  Leistung: Verh�ltnisskala 
#  Farbe: Nominalskala 
#  Ausstattung: Nominalskala
