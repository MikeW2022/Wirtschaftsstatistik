#  Erhebungsmerkmale - Aufgabe

#  Betrachtet werden folgende Erhebungsmerkmale: 

#  1)	K�rpergewicht.
#  2)	K�rpergr��e.
#  3)	G�teklasse.
#  4)	Geschlecht.
#  5)	Beruf.
#  6)	Jahresumsatz (in Mio. Euro).
#  7)	Familienstand.
#  8)	Erreichte Klausurpunkte.
#  9)	Geschwindigkeit.
#  10)	Nationalit�t.
#  11)	Windst�rke.
#  12)	Postleitzahl.
#  13)	Klausurnote.
#  14)	Temperatur (in C).
#  15)	Temperatur (in K).
#  16)	Zinsen.
#  17)	Telefonnummer.
#  18)	Geburtsdatum.
#  19)	Lebensalter.
#  20)	Konfektionsgr��e.
#  21)	W�hlerstimmen.
#  22)	Todesursache.
#  23)	Wohnfl�che.
#  24)	Wartezeit.
#  25)	Tageszeit.
#  26)	Geburten.
#  27)	Monatsgehalt.

#  a)  Geben Sie die Skalierung der Merkmale an. 
#  b)  Nennen Sie die diskreten,  die stetigen und
#      die quasi-stetigen Merkmale.
#  c)  Welche Merkmale sind ihrem Wesen nach dichotom? 
#  d)  Gliedern Sie die Merkmale in qualitative und
#      quantitative Merkmale. 

##########

#  Erhebungsmerkmale - L�sung

#  a)
#  Nominalskaliert: Geschlecht, Beruf, Familienstand,
#                   Nationalit�t, Postleitzahl, Telefonnummer,
#                   Todesursache
#  Ordinalskaliert: G�teklasse, Windst�rke, Klausurnote,
#                   Konfektionsgr��e
#  Intervallskaliert: Temperatur (in C), Geburtsdatum, Tageszeit
#  Verh�ltnisskaliert: K�rpergewicht, K�rpergr��e, Jahresumsatz,
#                      Geschwindigkeit, Temperatur (in K), Zinsen,
#                      Lebensalter, Wohnfl�che, Wartezeit, Monatsgehalt
#  Absolutskaliert: Erreichte Klausurpunkte, W�hlerstimmen, Geburten

#  b)
#  diskret: Erreichte Klausurpunkte, Zinsen, Geburtsdatum,
#           W�hlerstimmen, Geburten, Monatsgehalt
#  quasi-stetig: Jahreumsatz (in Mio. Euro)
#  stetig: K�rpergewicht, K�rpergr��e, Geschwindigkeit,
#          Temperatur (in C),Temperatur (in K), Lebensalter,
#          Wohnfl�che, Wartezeit, Tageszeit

#  c)
#  dichotom: Lange wurde das Geschlecht als dichotomes Merkmal
# angegeben. Die Realit�t zeigt jedoch, dass sowohl das biologische
# als auch das gesellschaftliche Geschlecht in mehr Facetten existiert. 

#  d)
#  qualitativ:
#  G�teklasse, Geschlecht, Beruf, Familienstand, Nationalit�t, 
#  Windst�rke, Postleitzahl, Klausurnote, Telefonnummer,   
#  Konfektionsgr��e, Todesursache
#  quantitativ:
#  K�rpergewicht, K�rpergr��e, Jahreumsatz (in Mio. Euro), 
#  Erreichte  Klausurpunkte, Geschwindigkeit,
#  Temperatur (in C), Temperatur (in K), Zinsen,
#  Geburtsdatum, Lebensalter, W�hlerstimmen, Wohnfl�che,
#  Wartezeit, Tageszeit, Geburten, Monatsgehalt