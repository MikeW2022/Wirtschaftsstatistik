#  St�rf�lle - Aufgabe

#  In einem Krimsektgesch�ft auf Krim wurden in den Monaten
#  Januar 2000 bis Dezember 2001 folgende Anzahl von St�rf�llen
#  registriert:

stoerfaelle <- data.frame(Monat=c("Jan","Feb","Mae","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"),Jahr_2000=c(0,4,1,4,2,8,2,4,3,2,1,6),Jahr_2001=c(7,1,6,1,9,7,8,8,4,3,7,0))

#  a) Wie lautet
#  - Merkmalstr�ger?
#  - statistische Gesamtheit?
#  - Identifikationsmerkmale?
#  - Erhebungsmerkmal?
#  - Skala?
#  - Urliste?

#  b) Klassifizieren Sie das Erhebungsmerkmal

##########

#  St�rf�lle - L�sung

#  a)
#  - Merkmalstr�ger: Monat
#  - statistische Gesamtheit: 24 Monate
#  - Identifikationsmerkmale: Monat (sachlich), Krim (�rtlich),
#                             2000 bis 2001 (zeitlich)
#  - Erhebungsmerkmal: Anzahl der St�rf�lle im Monat
#  - Skala: kardinal bzw. absolut skaliert
#  - alle n=24 erfassten Anzahlen

#  b)
#  Das Erhebungsmerkmal ist diskret und absolut skaliert