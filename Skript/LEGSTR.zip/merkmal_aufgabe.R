#  Merkmale einordnen - Aufgabe

#  Ordnen Sie die Merkmale des folgenden Data Frames richtig ein ...

merkmalliste <- data.frame(Gesamtheit=c("Familien","Betriebe","Wetter","Staedte","Adresse","Wohnung","Mensch","Kinder einer Schulklasse","Gestaltungsmittel","Baufirma","Temperaturmessung","Bundeswehr","Personen eines Haushaltes","Bevoelkerung","Tagesproduktion von Gluehlampen","Arbeit","Kleidung","Statistikklausur"),Merkmale=c("Kinderzahl","Umsatz","Windstaerke","Anzahl der Einwohner","Postleitzahl","Nettomiete","Intelligenzquotient","Koerpergroesse","Farbe","Kredithoehe","Temperatur in Grad Celsius","Militaerischer Rang","Koerpergewicht","Berufsbezeichnung","Lebensdauer","Arbeitslohn","Konfektionsgroesse","erreichte Punktzahl"),Auspraegungen=c("1, 2, 3, ...","10 Mio Euro, 200 Mio Euro, 8000 Mio Euro","schwach, stark, sehr stark, Orkan","10899, 20988, 158333","10050, 13562, 02744","350.43 Euro, 504.54 Euro, 694,94 Euro","IQ 70, IQ 90, IQ 110","132.3 cm, 135.3 cm, 140.4 cm","rot, gruen, blau, grau, orange","5 Mio Euro, 10 Mio Euro, 15 Mio Euro","0 Grad, 10 Grad, 25 Grad","Leutnant, Hauptmann, Major, ...","38.6kg, 67.9 kg, 88.4 kg","Mathematiker, Arzt, Baecker","2000 Stunden, 2500 Stunden, 3000 Stunden","1300 Euro, 2100 Euro, 4000 Euro","XS, S, M, L, XL, XXL","20, 14, 23, 30"))

#  ... und zwar in diesen Data Frame:

tabelle <- data.frame(Begriff_nominal=c("x"),Intensitaet_ordinal=c("x"),stetig_intervall=c("x"),stetig_verhaeltnis=c("x"),quasistetig_verhaeltnis=c("x"),diskret_verhaeltnis=c("x"),diskret_absolut=c("x"))
