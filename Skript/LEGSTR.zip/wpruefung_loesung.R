#  Wiederholungspr�fung - Aufgabe

#  Die folgende Urliste beinhaltet die Anzahl der Wiederholungs-
#  pr�fungen im Fach Statistik von 117 Studenten einer Berliner
#  Fachhochschule, die im Verlauf des WS 2001 ihre Pr�fung
#  absolvierten.

urliste <- c(0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,2,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,3,0,0,1,0,0,0,0,2,0,1,0,1,0,1,0,0,0,1,0,0,1,1,0,1,0,0,1,0,0,0,0,0,1,0,0,0,1,0,2,1,1,0,0,0,0,0,1,0,1,1,1,1,0,2,0,1,1,2,1,1,0,1,0)

#  a) Erl�utern Sie am konkreten Sachverhalt die Begriffe:
#  - Merkmalstr�ger
#  - statistische Gesamtheit
#  - Identifikationsmerkmale
#  - Erhebungsmerkmal
#  - Skala
#  - Urliste.

#  b) Klassifizieren Sie das Erhebungsmerkmal.

##########

#  Wiederholungspr�fung - L�sung

#  a)
#  - Merkmalstr�ger: Student
#  - statistische Gesamtheit: 117 Studenten
#  - Identifikationsmerkmale: Student (sachlich),
#    Berliner Fachhochschule (�rtlich), WS 2001 (zeitlich)
#  - Erhebungsmerkmal: Anzahl der Pr�fungswiederholungen
#    im Fach Statistik
#  - Skala: kardinal bzw. absolut skaliert
#  - Urliste: alle n=117 erfassten Anzahlen

#  b)
#  Das Erhebungsmerkmal ist diskret und absolut skaliert.