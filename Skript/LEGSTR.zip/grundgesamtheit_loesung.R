#  Grundgesamtheit - Aufgabe

#  Nennen Sie zu folgenden Fragestellungen die jeweils relevante
#  Grundgesamtheit:
#  1) Wird die FDP die 5% H�rde �berspringen k�nnen?
#  2) Wie hoch ist der Frauenanteil in ihrem Kurs
#     Wirtschaftsmathematik 1?
#  3) Wie gro� ist das durschnittliche K�rpergewicht
#     vollj�hriger Bundesb�rger?
#  4) Wie wirken sich die Luftschadstoffe auf die Gesundheit
#     der Lungen von Neugeborenen in der EU aus?
#  5) Wie lange ist die durschnittliche Lebensdauer einer 40 Watt
#     Gl�hbirne?

#  Zusatz:
#  In welchen F�llen ist eine Totalerhebung sinnvoll, wann eine
#  Stichprobe? Worauf ist bei der Benutzung einer Stichprobe zur
#  Beantwortung der Fragen zu achten?

##########

#  Grundgesamtheit - L�sung

#  1) Alle wahlberechtigten Bundesb�rger
#  2) Alle Teilnehmer Ihres Kurses
#  3) Alle vollj�hrigen Bundesb�rger
#  4) Alle Neugeborene in der EU
#  5) Alle 40 Watt Gl�hbirnen

#  Zusatz
#  Es ist nur zur Beantwortung von Frage 2 eine Totalerhebung sinnvoll.
#  Die Stichprobe muss zum einen m�glichst repr�sentativ sein,
#  zum anderen ist zu beachten, dass die Pr�zision der Aussage vom
#  Umfang der Stichprobe abh�ngt.