#  Wiederholungspr�fung - Aufgabe

#  Die folgende Urliste beinhaltet die Anzahl der Wiederholungs-
#  pr�fungen im Fach Statistik von 117 Studenten einer Berliner
#  Fachhochschule, die im Verlauf des WS 2001 ihre Pr�fung
#  absolvierten.

urliste <- c(0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,2,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,3,0,0,1,0,0,0,0,2,0,1,0,1,0,1,0,0,0,1,0,0,1,1,0,1,0,0,1,0,0,0,0,0,1,0,0,0,1,0,2,1,1,0,0,0,0,0,1,0,1,1,1,1,0,2,0,1,1,2,1,1,0,1,0)

#  a) Erl�utern Sie am konkreten Sachverhalt die Begriffe:
#  - Merkmalstr�ger
#  - statistische Gesamtheit
#  - Identifikationsmerkmale
#  - Erhebungsmerkmal
#  - Skala
#  - Urliste.

#  b) Klassifizieren Sie das Erhebungsmerkmal.
