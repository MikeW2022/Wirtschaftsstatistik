#  Personalausweis - Aufgabe

#  Im Personalausweis sind unter anderem folgende Angaben vermerkt:
#  Name, Geburtstag, Gr��e, Augenfarbe, Austellungsdatum.
#  Zu welchen Skalenarten geh�ren diese Variablen?
