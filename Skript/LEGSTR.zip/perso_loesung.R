#  Personalausweis - Aufgabe

#  Im Personalausweis sind unter anderem folgende Angaben vermerkt:
#  Name, Geburtstag, Gr��e, Augenfarbe, Austellungsdatum.
#  Zu welchen Skalenarten geh�ren diese Variablen?

##########

#  Personalausweis - L�sung

#  Name: nominal
#  Geburtstag: metrisch
#  Gr��e: metrisch (ratio)
#  Augenfarbe: nominal
#  Ausstellungsdatum: metrisch