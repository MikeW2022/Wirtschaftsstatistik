#  Wohnungen - Aufgabe

#  Bez�glich de Anzahl der Wohnr�ume f�r ein bestimmtes Jahr in der
#  Stadt N ergab die Statistik des Wohnungsbestands folgendes Bild:

wohnungsmarkt <- data.frame(Raumanzahl=c("1","2","3","4","5","6","7 oder mehr"),Wohnungsanzahl=c(130,615,1855,2720,1147,383,120))

#  a) Benennen Sie konkret:
#  - die kleinste statistische Einheit
#  - die statistische Gesamtheit
#  - die Identifikationsmerkmale
#  - das Erhebungsmerkmal

#  b) Wie ist das Erhebungsmerkmal skaliert
