#  Kursliste - Aufgabe

#  Erfragen Sie per e-mail oder Telefon folgende Informationen �ber
#  Ihre KomilitonInnen: Vorname, Nachname, Alter, Gr��e, Gewicht.
#  1. Erstellen Sie einen Data Frame mit Ihren Ergebnissen.
#  2. Welche Merkmale sind nominal-, welche verh�ltnis-,
#     intervall- oder absolutskaliert ?

##########

#  Kursliste - L�sung

#  1. Erstellen Sie einen Data Frame mit Ihren Ergebnissen.

kursliste <- data.frame(Vorname=c("Max","Maxi"),Nachname=c("Mustermann","Musterfrau"),Alter=c(20,24),Gr��e_in_m=c(1.83,1.68),Gewicht_in_kg=c(75,63))


#  2. Welche Merkmale sind nominal-, welche verh�ltnis-,
#     intervall- oder absolutskaliert?

#  nominal: Vorname, Nachname
#  verh�ltnis: Alter, Gr��e, Gewicht